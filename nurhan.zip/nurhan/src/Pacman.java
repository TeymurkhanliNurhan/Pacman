import javax.swing.ImageIcon;
import java.awt.event.KeyEvent;

public class Pacman {
    private int x;
    private int y;
    private int dx = 0;
    private int dy = 0;
    private int newDx;
    private int newDy;
    private final int TILE_SIZE = 28; // TILE_SIZE constant
    public int[][] PacmanLocs = new int[][]{{x, y}, {x + TILE_SIZE - 1, y}, {x, y + TILE_SIZE - 1}, {x + TILE_SIZE - 1, y + TILE_SIZE - 1}};
    public int[][] newPacmanLocs;
    public int[][] newPacmanLocs2;

    private ImageIcon image;
    private Board board;

    public Pacman() {
        initPacman();
    }

    private void initPacman() {
        image = new ImageIcon("C:\\Users\\Nurhan\\IdeaProjects\\nurhan\\src\\pac0.png");
        x = TILE_SIZE;
        y = TILE_SIZE;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public void move() {
        int newX = x + newDx;
        int newY = y + newDy;
        int newX2 = x + dx;
        int newY2 = y + dy;
        newPacmanLocs = new int[][]{{newX, newY}, {newX + TILE_SIZE - 1, newY}, {newX, newY + TILE_SIZE - 1}, {newX + TILE_SIZE - 1, newY + TILE_SIZE - 1}};
        newPacmanLocs2 = new int[][]{{newX2, newY2}, {newX2 + TILE_SIZE - 1, newY2}, {newX2, newY2 + TILE_SIZE - 1}, {newX2 + TILE_SIZE - 1, newY2 + TILE_SIZE - 1}};

        if (!board.isWall(newPacmanLocs)) {
            PacmanLocs = newPacmanLocs;
            x = newX;
            y = newY;
            dx = newDx;
            dy = newDy;
        } else {
            if (isZero(dy) != isZero(newDy)) {
                if (board.isWall(newPacmanLocs2)) {
                    newDx = 0;
                    newDy = 0;
                    move();
                }
                y = y + dy;
                x = x + dx;
            }
        }

        pasWall(); // PasWall metodunu burada çağırıyoruz
    }

    public boolean isZero(int x) {
        return x == 0;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, TILE_SIZE, TILE_SIZE);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public ImageIcon getImage() {
        return image;
    }

    public void pasWall() {
        int maxX = (board.getMap().length-1) * TILE_SIZE;
        int maxY = (board.getMap()[0].length-1) * TILE_SIZE;

        if (x > maxX) x = 0;
        else if (x < 0) x = maxX ;
        if (y > maxY) y = 0;
        else if (y < 0) y = maxY;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            newDx = -7;
            newDy = 0;
            move();
        }

        if (key == KeyEvent.VK_RIGHT) {
            newDx = 7;
            newDy = 0;
            move();
        }

        if (key == KeyEvent.VK_UP) {
            newDy = -7;
            newDx = 0;
            move();
        }

        if (key == KeyEvent.VK_DOWN) {
            newDy = 7;
            newDx = 0;
            move();
        }
    }

    public void setPosition(int a, int b) {
        x = a;
        y = b;
    }
}
