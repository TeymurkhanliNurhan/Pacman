import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Menu extends JFrame implements ActionListener {
    private JButton newGameButton;
    private JButton highScoresButton;
    private JButton exitButton;

    public Menu() {
        setTitle("Menu");
        setSize(400, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        // Butonlar oluşturuluyor
        newGameButton = new JButton("New Game");
        highScoresButton = new JButton("High Scores");
        exitButton = new JButton("Exit");

        // Butonlara action listener ekleniyor
        newGameButton.addActionListener(this);
        highScoresButton.addActionListener(this);
        exitButton.addActionListener(this);

        // Butonlar frame'e ekleniyor
        add(newGameButton);
        add(highScoresButton);
        add(exitButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == newGameButton) {
            SwingUtilities.invokeLater(() -> new Screen());
        } else if (e.getSource() == highScoresButton) {
            displayHighScores();
        } else if (e.getSource() == exitButton) {
            System.exit(0);
        }
    }

    private void displayHighScores() {
        List<Integer> scores = readScoresFromFile("data.txt");
        Collections.sort(scores, Collections.reverseOrder());
        StringBuilder message = new StringBuilder("High Scores:\n");
        for (int score : scores) {
            message.append(score).append("\n");
        }
        JOptionPane.showMessageDialog(this, message.toString(), "High Scores", JOptionPane.INFORMATION_MESSAGE);
    }

    private List<Integer> readScoresFromFile(String fileName) {
        List<Integer> scores = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    scores.add(Integer.parseInt(line));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return scores;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Menu());
    }
}

