import javax.swing.ImageIcon;
import java.util.Random;

public class Ghost {
    private int x;
    private int y;
    private int dx;
    private int dy;
    private Pacman pacman;
    public int[][] GhostLocs;
    public int[][] newGhostLocs;

    private ImageIcon image;
    private Board board;
    private final int TILE_SIZE = 28;
    private final Random random = new Random();

    public Ghost() {
        initGhost();
    }

    private void initGhost() {
        image = new ImageIcon("C:\\Users\\Nurhan\\IdeaProjects\\nurhan\\src\\1.png");
        x =13 * TILE_SIZE;
        y = 1 * TILE_SIZE;
    }

    public void setPacman(Pacman pacman) {
        this.pacman = pacman;
    }

    public void move() {
        int newX = x + dx;
        int newY = y + dy;
        newGhostLocs = new int[][]{{newX, newY}, {newX + TILE_SIZE - 1, newY}, {newX, newY + TILE_SIZE - 1}, {newX + TILE_SIZE - 1, newY + TILE_SIZE - 1}};

        if (!board.isWall(newGhostLocs)) {
            GhostLocs = newGhostLocs;
            x = newX;
            y = newY;
            for (int i = 0; i < pacman.PacmanLocs.length; i++) {
                // if (collapseWithGhost(pacman.PacmanLocs[i])) board.removeAll();
            }
        } else {
            randomMove();
        }
    }

    public void randomMove() {
        int direction = random.nextInt(4);
        switch (direction) {
            case 0 -> {
                dx = -6;
                dy = 0;
            }
            case 1 -> {
                dx = 6;
                dy = 0;
            }
            case 2 -> {
                dx = 0;
                dy = -6;
            }
            case 3 -> {
                dx = 0;
                dy = 6;
            }
        }
        move();
    }

    // Finding smart move by ghost to get closer to pacman
    public void correctMove(int gX, int gY, int pX, int pY) {
        int difX = Math.abs(pX - gX);
        int difY = Math.abs(pY - gY);

        if (difY >= difX) {
            dx = 0;
            dy = (pY - gY >= 0 ? 6 : -6);
            newGhostLocs = new int[][]{{gX, gY + dy}, {gX + TILE_SIZE - 1, gY + dy}, {gX, gY + TILE_SIZE - 1 + dy}, {gX + TILE_SIZE - 1, gY + TILE_SIZE - 1 + dy}};
            if (board.isWall(newGhostLocs)) {
                dx = (pX - gX >= 0 ? 6 : -6);
                dy = 0;
                newGhostLocs = new int[][]{{gX + dx, gY}, {gX + TILE_SIZE - 1 + dx, gY}, {gX + dx, gY + TILE_SIZE - 1}, {gX + TILE_SIZE - 1 + dx, gY + TILE_SIZE - 1}};
                if (board.isWall(newGhostLocs)) {
                    randomMove();
                } else {
                    move();
                }
            } else {
                move();
            }
        } else {
            dx = (pX - gX >= 0 ? 6 : -6);
            dy = 0;
            newGhostLocs = new int[][]{{gX + dx, gY}, {gX + TILE_SIZE - 1 + dx, gY}, {gX + dx, gY + TILE_SIZE - 1}, {gX + TILE_SIZE - 1 + dx, gY + TILE_SIZE - 1}};
            if (board.isWall(newGhostLocs)) {
                dx = 0;
                dy = (pY - gY >= 0 ? 6 : -6);
                newGhostLocs = new int[][]{{gX, gY + dy}, {gX + TILE_SIZE - 1, gY + dy}, {gX, gY + TILE_SIZE - 1 + dy}, {gX + TILE_SIZE - 1, gY + TILE_SIZE - 1 + dy}};
                if (board.isWall(newGhostLocs)) {
                    randomMove();
                } else {
                    move();
                }
            } else {
                move();
            }
        }
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public ImageIcon getImage() {
        return image;
    }

    public boolean collapseWithGhost(int[] arr) {
        boolean col = false;
        for (int i = 0; i < newGhostLocs.length; i++) {
            if ((arr[0] >= newGhostLocs[0][0]) && arr[1] >= newGhostLocs[0][1] && arr[0] <= newGhostLocs[3][0] && arr[1] <= newGhostLocs[3][1])
                col = true;
        }

        return col;
    }

    public void setPosition(int a, int b) {
        x = a;
        y = b;
    }
}
