import javax.swing.ImageIcon;

public class Food {
    private int x;
    private int y;
    private ImageIcon image;
    private Board board;
    public int[][] FoodLocs;

    private final int TILE_SIZE = 28;

    public Food(int x, int y) {
        this.x = x;
        this.y = y;
        initFood();
        FoodLocs = new int[][]{{x, y}, {x + TILE_SIZE, y}, {x, y + TILE_SIZE}, {x + TILE_SIZE, y + TILE_SIZE}};
    }

    private void initFood() {
        image = new ImageIcon("C:\\Users\\Nurhan\\IdeaProjects\\nurhan\\resources\\images\\map_segments_28px\\30.png");
    }

    public void setBoard(Board board) {this.board = board;}

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public ImageIcon getImage() {
        return image;
    }
}
