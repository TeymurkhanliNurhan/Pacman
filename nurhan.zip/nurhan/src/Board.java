import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Board extends JLayeredPane implements ActionListener {

    private Timer timer;
    private Pacman pacman;
    private Ghost ghost;
    private JLabel ghostLabel;
    private JLabel pacmanLabel;
    private JLabel scoreLabel;
    private JLabel livesLabel; // Pacman's lives label
    private final int TILE_SIZE = 28;
    private int[][] map;
    public final List<int[]> walls;
    public List<JLabel> foods;
    public List<Food> foodItems;
    public List<JLabel> obstacLabel;
    public List<Obstacle> obstacles;
    private int score;
    private int foodCount = 0;
    private int lives = 3; // Initial lives

    private final ImageIcon[] images;

    public Board() {
       // map = new int[15][15];
        walls = new ArrayList<>();
        foods = new ArrayList<>();
        foodItems = new ArrayList<>();
        obstacles = new ArrayList<>();
        obstacLabel = new ArrayList<>();
        images = new ImageIcon[40]; // Assuming maximum index in map is 30
        score = 0;
        loadImages();
        loadMap("C:\\Users\\Nurhan\\IdeaProjects\\nurhan\\maps\\map1");

        initBoard();
    }

    private void initBoard() {
        setFocusable(true);
        setLayout(null);

        pacman = new Pacman();
        pacman.setBoard(this);
        pacmanLabel = new JLabel(pacman.getImage());
        pacmanLabel.setBounds(pacman.getX(), pacman.getY(), pacman.getImage().getIconWidth(), pacman.getImage().getIconHeight());
        add(pacmanLabel, JLayeredPane.MODAL_LAYER);

        ghost = new Ghost();
        ghost.setBoard(this);
        ghost.setPacman(pacman);
        ghostLabel = new JLabel(ghost.getImage());
        ghostLabel.setBounds(ghost.getX(), ghost.getY(), ghost.getImage().getIconWidth(), ghost.getImage().getIconHeight());
        add(ghostLabel, JLayeredPane.MODAL_LAYER);

        // Create score label
        scoreLabel = new JLabel("Score: " + score);
        scoreLabel.setBounds(10, 10, 100, 30);
        add(scoreLabel, JLayeredPane.PALETTE_LAYER);

        // Create lives label
        livesLabel = new JLabel("Lives: " + lives);
        livesLabel.setBounds(10, 50, 100, 30);
        add(livesLabel, JLayeredPane.PALETTE_LAYER);

        // Draw the map
        drawMap();

        // Add all food labels to the board after drawing the map
        for (JLabel foodLabel : foods) {
            add(foodLabel, JLayeredPane.MODAL_LAYER);
        }

        addKeyListener(new TAdapter());

        timer = new Timer(40, this);
        timer.start();

        Thread thread = new Thread(() -> {
            while (true) {
                try {
                    ghost.correctMove(ghost.getX(), ghost.getY(), pacman.getX(), pacman.getY());
                    ghostLabel.setLocation(ghost.getX(), ghost.getY());
                    repaint();
                    checkGhostCollision(); // Check collision with ghost
                    Thread.sleep(100); // 0.1 second wait
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();
    }

    private void loadImages() {
        for (int i = 0; i <= 30; i++) {
            String path = String.format("C:\\Users\\Nurhan\\IdeaProjects\\nurhan\\resources\\images\\map_segments_28px\\%d.png", i);
            images[i] = new ImageIcon(path);
        }
    }

    private void loadMap(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            List<String[]> lines = new ArrayList<>();
            String line;
            while ((line = br.readLine()) != null) {
                String[] tokens = line.split(" ");
                lines.add(tokens);
            }
            int rows = lines.size();
            int cols = lines.get(0).length;
            map = new int[rows][cols];
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    map[row][col] = Integer.parseInt(lines.get(row)[col]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void drawMap() {
        for (int row = 0; row < map.length; row++) {
            for (int col = 0; col < map[row].length; col++) {
                int tile = map[row][col];

                Obstacle obstacle1 = new Obstacle(9, col * TILE_SIZE, row * TILE_SIZE);
                JLabel label1 = new JLabel(obstacle1.getImage());
                label1.setBounds(col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                obstacLabel.add(label1);
                obstacles.add(obstacle1);
                add(label1, JLayeredPane.DEFAULT_LAYER);

                Obstacle obstacle = new Obstacle(tile, col * TILE_SIZE, row * TILE_SIZE);
                JLabel label = new JLabel(obstacle.getImage());
                label.setBounds(col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                obstacLabel.add(label);
                obstacles.add(obstacle);
                add(label, JLayeredPane.PALETTE_LAYER);

                if (tile == 9) {
                    Food food = new Food(col * TILE_SIZE, row * TILE_SIZE);
                    JLabel foodLabel = new JLabel(food.getImage());
                    foodLabel.setBounds(food.getX(), food.getY(), food.getImage().getIconWidth(), food.getImage().getIconHeight());
                    foods.add(foodLabel);
                    foodItems.add(food);
                    foodCount++;
                } else {
                    for (int i = col * TILE_SIZE; i < col * TILE_SIZE + TILE_SIZE; i++) {
                        for (int j = row * TILE_SIZE; j < row * TILE_SIZE + TILE_SIZE; j++) {
                            int[] arr = new int[]{i, j};
                            walls.add(arr);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        pacman.move();
        pacmanLabel.setLocation(pacman.getX(), pacman.getY());
        checkFoodCollision();
        repaint();
    }

    private void checkFoodCollision() {
        List<JLabel> foodsToRemove = new ArrayList<>();
        List<Food> foodItemsToRemove = new ArrayList<>();
        for (int i = 0; i < foods.size(); i++) {
            JLabel foodLabel = foods.get(i);
            Food food = foodItems.get(i);
            if (pacman.getBounds().intersects(new Rectangle(foodLabel.getX(), foodLabel.getY(), foodLabel.getWidth(), foodLabel.getHeight()))) {
                foodsToRemove.add(foodLabel);
                foodItemsToRemove.add(food);
                score += 10;
                scoreLabel.setText("Score: " + score);
                foodCount--;
                if (foodCount == 0) {
                    restartGame();
                }
            }
        }
        foods.removeAll(foodsToRemove);
        foodItems.removeAll(foodItemsToRemove);
        for (JLabel foodLabel : foodsToRemove) {
            remove(foodLabel);
        }
    }

    private void checkGhostCollision() {
        if (pacman.getBounds().intersects(new Rectangle(ghostLabel.getX(), ghostLabel.getY(), ghostLabel.getWidth(), ghostLabel.getHeight()))) {
            lives--;
            livesLabel.setText("Lives: " + lives);
            if (lives <= 0) {
                gameOver();
            } else {
                resetPositions();
            }
        }
    }

    private void resetPositions() {
        pacman.setPosition(TILE_SIZE, TILE_SIZE); // Reset pacman to initial position
        pacmanLabel.setLocation(pacman.getX(), pacman.getY());
        ghost.setPosition(13 * TILE_SIZE, TILE_SIZE); // Reset ghost to initial position
        ghostLabel.setLocation(ghost.getX(), ghost.getY());
    }

    private void restartGame() {
        for (JLabel label : obstacLabel) {
            remove(label);
        }
        foods.clear();
        foodItems.clear();
        walls.clear();
        obstacles.clear();
        obstacLabel.clear();
        resetPositions();
        drawMap();
        for (JLabel foodLabel : foods) {
            add(foodLabel, JLayeredPane.MODAL_LAYER);
        }
        revalidate();
        repaint();
    }

    private void gameOver() {
        timer.stop();
        saveScoreToFile(score); // Save the score to the file
        JOptionPane.showMessageDialog(this, "Game Over! Final Score: " + score);
        System.exit(0);
    }

    private void saveScoreToFile(int score) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt", true))) {
            writer.write(String.valueOf(score));
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class TAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            pacman.keyPressed(e);
        }
    }

    public int[][] getMap() {
        return map;
    }

    public boolean isWall(int[][] arr) {
        for (int[] coord : arr) {
            for (int[] wall : walls) {
                if (wall[0] == coord[0] && wall[1] == coord[1]) {
                    return true;
                }
            }
        }
        return false;
    }
}
