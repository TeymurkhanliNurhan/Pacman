import javax.swing.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
      //  SwingUtilities.invokeLater(() ->new Screen());
        SwingUtilities.invokeLater(() ->new Menu());
       /* Board board=new Board();
        for (int[] a : board.walls){
            for (int i = 0; i < a.length; i++) {
                System.out.print(a[i]+" ");
            }
            System.out.println();
        }
*/

      //  ImageIcon imageIcon=new ImageIcon("C:\\Users\\Nurhan\\IdeaProjects\\nurhan\\resources\\images\\map_segments_28px\\32.png");
       // System.out.println(imageIcon.getIconHeight()+" "+imageIcon.getIconWidth());
/*
//checked: all map images are 28px * 28px
        for (int i = 1; i <27 ; i++) {
            String path = String.format("C:\\Users\\Nurhan\\IdeaProjects\\nurhan\\resources\\images\\map_segments_28px\\%d.png", i);
            ImageIcon imageIcon = new ImageIcon(path);
            // Get the width and height of the image
            int width = imageIcon.getIconWidth();
            int height = imageIcon.getIconHeight();
            // Print the width and height
            System.out.print("Width: " + width + " pixels");
            System.out.println("Height: " + height + " pixels");
        }

 */
    }
}
